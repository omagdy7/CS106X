// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

void generateMaze() {
    // TODO: Finish the code!

}
